var express = require('express');
var router = express.Router();

//增加引用函式

const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.all('/', function(req, res, next) {
    var data = req.session.data;
    var roomno = req.session.roomno;

    var bookingroomno = data.bookingroomno;

    console.log('bookingroomno：', bookingroomno);
    console.log('roomno：', roomno);

    // 建立一個新資料物件
    var newData={
        bookingroomno:bookingroomno,
        roomno:roomno
    } 
    console.log("已送交審核")    
    /**/
    bookingroom.add_detail(newData).then(d => {
        if (d==0){
            console.log('add：', 'addSuccess');
            res.render('audit');    //已送交審核
        }else{
            console.log('add：', 'addFail');
            res.render('addFail');
        }  
    })
    
});

module.exports = router;

