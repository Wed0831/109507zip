var express = require('express');
var router = express.Router();

//增加引用函式
const roomverify = require('./utility/roomverify');

//接收POST請求
router.post('/', function(req, res, next) {
    var bookingroomno = req.body.bookingroomno;   //取得借用編號
    var yn = [req.body.yesorno0, req.body.yesorno1, req.body.yesorno2, req.body.yesorno3, req.body.yesorno4, req.body.yesorno5, req.body.yesorno6, req.body.yesorno7, req.body.yesorno8, req.body.yesorno9];
    var yesorno = [];

    for(var i=0;i<bookingroomno.length;i++){
        yesorno.push(yn[i]);
    }
    
    var newData={
        bookingroomno:bookingroomno,
        yesorno:yesorno
    };


    console.log(newData);
    
    roomverify.update(newData).then(d => {
        console.log(d);
        if (d>=0){
            console.log("updateSuccess");
            res.render('updateSuccess');
            //res.redirect('/mail');
        }else{
            console.log("updateFail");
            //res.render('updateFail');
        }  
    })
});

//匯出
module.exports = router;

/*
reason: req.body.reason,   
borrowdate: req.body.borrowdate,
borrowtime: req.body.borrowtime,
endtime: req.body.endtime,
role: req.body.role,
evidence: req.body.evidence,
*/