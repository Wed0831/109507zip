var express = require('express');
var router = express.Router();

//增加引用函式
const deviceverify = require('./utility/deviceverify');

//接收POST請求
router.post('/', function(req, res, next) {
    var bookingdeviceno = req.body.bookingdeviceno;   //取得產品編號
    var yesorno = req.body.yesorno;

    var newData={
        bookingdeviceno:bookingdeviceno,                   
        yesorno:yesorno
    } 
    console.log(newData);
    deviceverify.update_return(newData).then(d => {
        if (d>=0){
            res.render('updateSuccess');
        }else{
            res.render('updateFail');
        }  
    })
});

//匯出
module.exports = router;