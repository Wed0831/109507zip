'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

var query_no = async function(userno){
    var result={};
    
    await sql('SELECT * FROM bookingdevice AS a JOIN bookingdevice_detail AS b on a.bookingdeviceno = b.bookingdeviceno WHERE a.userno = $1', [userno])
        .then((data) => {
            result = data.rows;   
        }, (error) => {
            result = null;
        });


    console.log(result);
    return result;  
}

//匯出
module.exports = {query_no};