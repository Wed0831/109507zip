var express = require('express');
var router = express.Router();

//增加引用函式
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.all('/', function(req, res, next) {
    var roomno = req.body.roomno;               
    var bookingroomno = req.session.bookingroomno;
    
    console.log(roomno);
    console.log(bookingroomno);

    // 建立一個新資料物件
    var newData={
        roomno:roomno,
        bookingroomno:bookingroomno
    } 

    bookingroom.add_detail(newData).then(d => {
        if (d==0){
            res.render('addSuccess');   //審核中
        }else{
            res.render('addFail');      //借用失敗
        }  
    })
});

module.exports = router;