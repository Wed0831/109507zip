var express = require('express');
var router = express.Router();

//增加引用函式
var moment = require('moment');
var today = require('silly-datetime');
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.post('/', function(req, res, next) {
    var userno = req.body.userno;                       
    var reason = req.body.reason; 
    var roomno = req.body.roomno;
    var bookingdate = today.format("YYYY-MM-DD HH:mm:ss"); 
    var borrowdate = moment(req.body.borrowdate).format("YYYY-MM-DD HH:mm:ss");  
    var endate = moment(req.body.endate).format("YYYY-MM-DD HH:mm:ss");       
    
    req.session.now = bookingdate;
    req.session.roomno = roomno;

    // 建立一個新資料物件
    var newData={
        userno:userno,
        reason:reason,
        bookingdate:bookingdate,
        borrowdate:borrowdate,
        endate:endate
    } 

    console.log(userno);
    console.log(reason);
    console.log(bookingdate);
    console.log(borrowdate);
    console.log(endate);
        
    bookingroom.add(newData).then(d => {
        if (d==0){
            res.redirect('/booking_room_query');   //審核中
            //res.render('addSuccess');
        }else{
            res.render('addFail');      //借用失敗
        }  
    })
});

module.exports = router;