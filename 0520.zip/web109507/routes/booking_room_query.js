var express = require('express');
var router = express.Router();

//增加引用函式
var today = require('silly-datetime');
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.all('/', function(req, res, next) {
    var roomno = req.body.roomno;             
    var now = today.format("YYYY-MM-DD HH:mm:ss");   
    
    console.log(roomno);
    console.log(now);

    if(bookingroom.bookingdate == now){
        user.query(bookingdate).then(data => {
            if (data==null){
                res.render('error');  //導向錯誤頁面
            }else if(data==-1){
                res.render('notFound');          
            }else{
                //res.render('user_query', {item:data});  //將資料傳給顯示頁面
                req.session.bookingroomno = bookingroomno;
                console.log(req.session.bookingroomno);
                res.redirect('/booking_room_detail');
            }  
        })
    }
});

module.exports = router;