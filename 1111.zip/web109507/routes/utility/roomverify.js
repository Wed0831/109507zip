'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
//審核
//------------------------------------------
var query = async function(yesorno){
    var result={};

    await sql('SELECT * FROM bookingroom as a JOIN bookingroom_detail as b on a.bookingroomno = b.bookingroomno WHERE yesorno is null or a.yesorno = $1 ORDER BY a.bookingroomno, a."role"', [yesorno])
        .then((data) => {
            result = data.rows;
        }, (error) => {
            result = null;
        });       
    console.log(result);
    
    return result;
}

var update = async function(newData){
    var results=0;
    console.log(newData);
    console.log("newData.bookingroomno："+ newData.bookingroomno);
    for(var i=0; i<newData.bookingroomno.length;i++){
        console.log("i：" + i);
        console.log("newData.bookingroomno.length："+ newData.bookingroomno.length);
        console.log("newData.bookingroomno[i]："+ newData.bookingroomno[i]);
        console.log();

        await sql('UPDATE bookingroom SET yesorno=$1 WHERE bookingroomno=$2', [newData.yesorno[i], newData.bookingroomno[i]])
        .then((data) => {
            results = results + data.rowCount;  
        }, (error) => {
            results = -1;
        });
    }/**/
        
    console.log(results);
    return results;
}

//------------------------------------------
//查詢
//------------------------------------------
var query_no = async function(userno){
    var result={};
    
    await sql('SELECT * FROM (bookingroom as a JOIN bookingroom_detail as b on a.bookingroomno = b.bookingroomno) JOIN room as c on b.roomno = c.roomno WHERE a.userno = $1', [userno])
        .then((data) => {
            result = data.rows;   
        }, (error) => {
            result = null;
        });


    console.log(result);
    return result;

    
}

//匯出
module.exports = {query, update, query_no};