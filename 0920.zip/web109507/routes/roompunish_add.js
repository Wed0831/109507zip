var express = require('express');
var router = express.Router();

//增加引用函式
const roompunish = require('./utility/roompunish');

//接收POST請求
router.post('/', function(req, res, next) {
    var bookingroomno = req.body.bookingroomno;                  
    var userno = req.body.userno;                 
    var startdate = req.body.startdate;  
    var finishdate = req.body.finishdate;                  
    var roompunishdetail = req.body.roompunishdetail;  

    // 建立一個新資料物件
    var newData={
        bookingroomno:bookingroomno,
        userno:userno,
        startdate:startdate,
        finishdate:finishdate,
        roompunishdetail:roompunishdetail
    } 
    
    roompunish.add(newData).then(d => {
        if (d==0){
            res.render('addSuccess');  //傳至成功頁面
        }else{
            res.render('addFail');     //導向錯誤頁面
        }  
    })
});

module.exports = router;