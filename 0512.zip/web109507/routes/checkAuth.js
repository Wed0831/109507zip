var express = require('express');
var router = express.Router();

//處理GET, POST, PUT, DELETE等所有請求
router.all('/', function(req, res, next) {
    //var shcemail = req.session.schemail;
    //var isEmployee = req.session.isEmployee;
    var email = req.session.email;
    console.log(email);
    
    //檢查是否有session註記
    
    if(email == "10556025@ntub.edu.tw" || email == null){  
        res.render('UnAuth');
    }else{
        next();
    }
});

module.exports = router;

/*
if(email == schemail){
    if(isEmployee == t){
        next();
    }else{
        res.render('UnAuth');   //無權利使用
    }
}else{
    res.render('loginFail');   //非本系師生
}

if(email == shcemail){
    res.render('loginSuccess'); //登入成功
}else{
    res.render('loginFail');    //非本系師生
}


*/


