var express = require('express');
var router = express.Router();

//增加引用函式
const roomverify = require('./utility/roomverify');

//接收POST請求
router.post('/', function(req, res, next) {
    var bookingroomno = req.body.bookingroomno;   //取得借用編號
    var userno = req.body.userno;   //取得使用者編號
    var yn = [req.body.yesorno0, req.body.yesorno1, req.body.yesorno2, req.body.yesorno3, req.body.yesorno4, req.body.yesorno5, req.body.yesorno6, req.body.yesorno7, req.body.yesorno8, req.body.yesorno9,
        req.body.yesorno10, req.body.yesorno11, req.body.yesorno12, req.body.yesorno13, req.body.yesorno14, req.body.yesorno15, req.body.yesorno16, req.body.yesorno17, req.body.yesorno18, req.body.yesorno19]
    
    var yesorno = [];



    for(var i=0;i<bookingroomno.length;i++){
        yesorno.push(yn[i]);
    }
    var newData={
        bookingroomno:bookingroomno,
        userno:userno,                   
        yesorno:yesorno
    } 
    console.log(newData);
    
    roomverify.update(newData).then(d => {
        if (d>=0){
            console.log("updateSuccess");
            res.render('updateSuccess');
            //res.redirect('/mail');
        }else{
            console.log("updateFail");
            res.render('updateFail');
        }  
    })
});

//匯出
module.exports = router;

/*
reason: req.body.reason,   
borrowdate: req.body.borrowdate,
borrowtime: req.body.borrowtime,
endtime: req.body.endtime,
role: req.body.role,
evidence: req.body.evidence,
*/