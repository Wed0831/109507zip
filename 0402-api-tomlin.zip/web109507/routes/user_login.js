var express = require('express');
var router = express.Router();

//增加引用函式
const user = require('./utility/user');

//接收POST請求
router.post('/', function(req, res, next) {
    var id = req.body.schemail;                 //取得帳號
    var password = req.body.password;           //取得密碼

    user.login(id, password).then(d => {
        if (d==null){
            req.session.schemail = null;
            req.session.username = null;           
            res.render('loginFail');  //傳至登入失敗
        }else{
            req.session.schemail = d.schemail;
            req.session.username = d.username;
            res.render('user_show', {name:d.username});   //導向使用者
        }  
    })
});

module.exports = router;