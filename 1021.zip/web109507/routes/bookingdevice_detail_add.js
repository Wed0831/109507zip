var express = require('express');
var router = express.Router();

//增加引用函式

const bookingdevice = require('./utility/bookingdevice');

//接收POST請求
router.all('/', function(req, res, next) {
    var data = req.session.data;
    var bookingdeviceno = data.bookingdeviceno;

    console.log('bookingdeviceno', bookingdeviceno);

    // 建立一個新資料物件
    var newData={bookingdeviceno:bookingdeviceno} 

    //console.log("已送交審核")    

    bookingdevice.add_detail(newData).then(d => {
        if (d==0){
            console.log('add：', 'addSuccess');
            res.render('audit');    //已送交審核
        }else{
            console.log('add：', 'addFail');
            res.render('addFail');
        }  
    })
    
});

module.exports = router;

