var express = require('express');
var router = express.Router();

//增加引用函式
var moment = require('moment');
var today = require('silly-datetime');
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.all('/', function(req, res, next) {
    var userno = req.body.userno;                       
    var reason = req.body.reason; 
    var roomno = req.body.roomno;
    var bookingdate = today.format("YYYY-MM-DD HH:mm:ss"); 
    var borrowdate = moment(req.body.borrowdate).format("YYYY-MM-DD HH:mm:ss");  
    var endate = moment(req.body.endate).format("YYYY-MM-DD HH:mm:ss");  

    req.session.bookingdate = bookingdate;
    req.session.roomno = roomno;

    // 建立一個新資料物件
    var newData={
        userno:userno,
        reason:reason,
        bookingdate:bookingdate,
        borrowdate:borrowdate,
        endate:endate
    } 

    console.log(userno);
    console.log(reason);
    console.log(bookingdate);
    console.log(borrowdate);
    console.log(endate);
        
    bookingroom.add(newData).then(d => {
        if (d==0){
            console.log('addSuccess');
            //res.redirect('/booking_room_detail');
        }else{
            console.log('addFail');
        }  
    })
});

module.exports = router;

/*
    bookingroom.query(bookingdate).then(data => {
        console.log(bookingdate);
        if (data==null || data == -1){
            console.log('error');  //導向錯誤頁面         
        }else{
            req.session.data = data;
            console.log(data);  //將資料傳給顯示頁面
        }  
    })

    
    var d = req.session.data;
    console.log(d);

    
    var bookingroomno = d;
    // 建立一個新資料物件
    var NewData={
        roomno:roomno,
        bookingroomno:bookingroomno
    } 
    
    console.log(roomno);
        
    bookingroom.add_detail(NewData).then(d => {
        if (d==0){
            res.render('addSuccess');   //審核中
            
        }else{
            res.render('addFail');      //借用失敗
        }  
    })
    */