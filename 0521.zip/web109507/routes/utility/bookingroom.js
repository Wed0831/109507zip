'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
// 新增商品
//------------------------------------------
var add = async function(newData){
    var result;

    await sql('INSERT INTO bookingroom (userno, reason, bookingdate, borrowdate, endate) VALUES ($1, $2, $3, $4, $5)', [newData.userno, newData.reason, newData.bookingdate, newData.borrowdate, newData.endate])
        .then((data) => {
            result = 0;  
        }, (error) => {
            result = -1;
        });
		
    return result;
}

var query = async function(bookingdate){
    var result={};
    
    await sql('SELECT * FROM "bookingroom" WHERE "bookingdate" = $1', [bookingdate])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });
		
    return result;
}

var add_detail = async function(newData){
    var result;

    await sql('INSERT INTO bookingroomdetail (bookingroomno, roomno) VALUES ($1, $2)', [newData.bookingroomno, newData.roomno])
        .then((data) => {
            result = 0;  
        }, (error) => {
            result = -1;
        });
		
    return result;
}

//匯出
module.exports = {add , query, add_detail};