var express = require('express');
var router = express.Router();

//增加引用函式
//var moment = require('moment');
//var today = require('silly-datetime');
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.all('/', function(req, res, next) {

    var roomno = req.session.roomno;
    var bookingdate = req.session.bookingdate;

    bookingroom.query(bookingdate).then(data => {
        if (data==null){
            console.log('error');  //導向錯誤頁面         
        }else{
            req.session.data = data;
            console.log(data);  //將資料傳給顯示頁面
        }  
    })
    
    /*
    // 建立一個新資料物件
    var NewData={
        roomno:roomno,
        bookingroomno:bookingroomno
    } 
    
    console.log(roomno);
        
    bookingroom.add_detail(NewData).then(d => {
        if (d==0){
            res.render('addSuccess');   //審核中
            
        }else{
            res.render('addFail');      //借用失敗
        }  
    })
    */
});

module.exports = router;