'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//---------------------------------------------
//登入
//---------------------------------------------
var login = async function(id, password){   
    var result;

    //取得員工資料
    await sql('SELECT * FROM school WHERE schemail=$1 and password=$2', [id, password])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];
            }else{
                result = null;
            } 
        }, (error) => {
            result = null;
        });
    
    //回傳物件
    return result;
}

//------------------------------------------
//新增
//------------------------------------------
var add = async function(newData){
    var result;
    await sql('INSERT INTO "school" ("schno", "schname", "password", "lineid", "schemail", "isEmployee", "restrict") VALUES ($1, $2, $3, $4, $5, $6, $7)', [newData.schno, newData.schname, newData.password, newData.lineid, newData.schemail, newData.isEmployee, newData.restrict])
        .then((data) => {
            result = 0;  
        }, (error) => {
            result = -1;
        });
		
    return result;
}

//----------------------------------
// 刪除
//----------------------------------
var remove = async function(schno){
    var result;

    await sql('DELETE FROM school WHERE schno = $1', [schno])
        .then((data) => {
            result = data.rowCount;   //刪除筆數(包括刪除0筆) 
        }, (error) => {
            result = -1;   //剛除失敗
        });
		
    return result;
}

//----------------------------------
// 更新商品
//----------------------------------
var update = async function(newData){
    var results;

    await sql('UPDATE "school" SET "schname"=$1, "isEmployee"=$2, "restrict"=$3 WHERE "schno" = $4', [newData.schname, newData.isEmployee, newData.restrict, newData.schno])
        .then((data) => {
            results = data.rowCount;  
        }, (error) => {
            results = -1;
        });
		
    return results;
}

//------------------------------------------
//執行資料庫動作的函式-取出單一商品
//------------------------------------------
var query = async function(schno){
    var result={};
    
    await sql('SELECT * FROM "school" WHERE "schno" = $1', [schno])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });
		
    return result;
}

var list = async function(){
    var result=[];
	
    await sql('SELECT * FROM "school" ORDER BY "schno"')
        .then((data) => {            
            result = data.rows;  
        }, (error) => {
            result = null;
        });
		
    return result;
}

//匯出
module.exports = {login, add, remove, update, query, list};