var pg = require('pg');
// 資料庫配置
var config = { 
    user:"tcmlcffsmhdxec",
    database:"d87tq6p6hnqbt2",
    password:"1d3f66e3407911142089ee9d9b20b1f84cc62108d5e2aa8c21c1109d88fddb5b",
    port:5432
}

// 建立連線池
var pool = new pg.Pool(config); 

// 查詢
pool.connect(function(err, client, done) { 
    if(err) {
        return console.error('資料庫連線出錯', err);
    }
    // 簡單輸出個 Hello World
    if(err){
        Client.query('SELECT $1::varchar AS OUT', "*@ntub.edu.tw", function(err, result) {
        done();// 釋放連線（將其返回給連線池）
        if(err) {
            return console.error('查詢出錯', err);
        }
        console.log(result.rows[0].out); //output: Hello World
        });
    }
});