var express = require('express');
var router = express.Router();

//處理GET, POST, PUT, DELETE等所有請求
router.all('/', function(req, res, next) {
    //var shcemail = req.session.schemail;
    //var isEmployee = req.session.isEmployee;
    var user_email = req.session.passport.user.emails[0].value;
    //檢查是否有session註記
    
    if(user_email == "105556025@ntub.edu.tw"){  
        res.render('UnAuth');
    }else{
        next();
    }
});

module.exports = router;

/*
if(user_email == schemail){
    if(isEmployee == true){
        next();
    }else{
        res.render('UnAuth');
    }
}else{
    res.render('UnAuth');
    signOut();
}


*/


