var express = require('express');
var router = express.Router();

//增加引用函式
var moment = require('moment');
var today = require('silly-datetime');
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.post('/', function(req, res, next) {
    var userno = req.body.userno;                       
    var reason = req.body.reason; 
    var roomno = req.body.roomno;
    var bookingdate = today.format("YYYY-MM-DD HH:mm:ss"); //申請日期
    var borrowdate = moment(req.body.borrowdate).format("YYYY-MM-DD");  //借用日  
    var borrowtime = req.body.borrowtime;   //借用時間
    var endtime = req.body.endtime;     //歸還時間
    var role = req.body.role;
    var evidence = req.body.evidence;   //圖片

    var borrowweek =  moment(req.body.borrowdate).format("E");  //借用日的星期

    req.session.bookingdate = bookingdate;  //借用日  
    req.session.roomno = roomno;    //教室編號

    // 建立一個新資料物件
    var newData={
        userno:userno,
        reason:reason,
        bookingdate:bookingdate,
        borrowdate:borrowdate,
        borrowtime:borrowtime,
        endtime:endtime,
        role:role,
        evidence:evidence
    } 

    console.log('userno：', userno);
    console.log('reason：', reason);
    console.log('bookingdate：', bookingdate);
    console.log('borrowdate：', borrowdate);
    console.log('borrowtime：', borrowtime);
    console.log('endtime：', endtime);
    console.log('borrowweek：',borrowweek);
    console.log('role：',role);
    console.log('evidence：',evidence);
    
    if(borrowtime >= endtime){
        console.log('歸還時間不能小於借用時間');
    }else{
        if(borrowweek == '6' || borrowweek == '7'){
            console.log('假日無法借用');
        }else{
            if(borrowtime < "08:00" || endtime > "21:50"){
                console.log("早上8點前以及晚上9：50之後不借用")
            }else{
                var time = (endtime - borrowtime);
                console.log("時間差：", time);
            }
        }


        /*
        bookingroom.add(newData).then(d => {
                if (d==0){
                    console.log('add：', 'addSuccess');
                    //res.redirect('/booking/date/query');
                }else{
                    console.log('add：', 'addFail');
                    //res.render('addFail');
                }  
            })
        */

    }

    
    /*
    bookingroom.add(newData).then(d => {
            if (d==0){
                console.log('add：', 'addSuccess');
                //res.redirect('/booking/date/query');
            }else{
                console.log('add：', 'addFail');
                //res.render('addFail');
            }  
        })
    */
    
});

module.exports = router;

