var express = require('express');
var router = express.Router();

//增加引用函式
const deviceverify = require('./utility/deviceverify');

//接收POST請求
router.post('/', function(req, res, next) {
    var bookingdeviceno = req.body.bookingdeviceno;   //取得產品編號

    var newData={
        bookingdeviceno:bookingdeviceno,                   //產品編號
        deviceno: req.body.deviceno,     //取得產品名稱
    } 
    console.log(newData);
    deviceverify.update_verify(newData).then(d => {
        if (d>=0){
            res.render('updateSuccess');  //傳至成功頁面
        }else{
            res.render('updateFail');     //導向錯誤頁面
        }  
    })
});

//匯出
module.exports = router;