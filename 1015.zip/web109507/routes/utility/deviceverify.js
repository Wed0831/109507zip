'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
// 審核
//------------------------------------------
var query_verify = async function(userno){
    var result={};
    
    await sql('SELECT * FROM bookingdevice AS a JOIN bookingdevice_detail AS b on a.bookingdeviceno = b.bookingdeviceno WHERE a.userno = $1', [userno])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });
		
    return result;
}

var update_verify = async function(newData){
    var results;

    await sql('UPDATE bookingdevice_detail SET deviceno=$1 WHERE bookingdeviceno = $2', [newData.deviceno, newData.bookingdeviceno])
        .then((data) => {
            results = data.rowCount;  
        }, (error) => {
            results = -1;
        });
	console.log(results);
    return results;
}


//------------------------------------------
// 歸還
//------------------------------------------



//------------------------------------------
// 查詢
//------------------------------------------
var query_no = async function(userno){
    var result={};
    
    await sql('SELECT * FROM bookingdevice AS a JOIN bookingdevice_detail AS b on a.bookingdeviceno = b.bookingdeviceno WHERE a.userno = $1', [userno])
        .then((data) => {
            result = data.rows;   
        }, (error) => {
            result = null;
        });


    console.log(result);
    return result;  
}

//匯出
module.exports = {query_verify, update_verify, query_no};